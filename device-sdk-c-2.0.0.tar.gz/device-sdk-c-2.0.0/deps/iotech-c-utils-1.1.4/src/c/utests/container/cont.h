/*
 * Copyright (c) 2020
 * IoTech Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "iot/container.h"
#include "iot/logger.h"

#ifndef _CUTIL_UTEST_CONT_H_
#define _CUTIL_UTEST_CONT_H_

extern void cunit_cont_test_init (void);

#endif
