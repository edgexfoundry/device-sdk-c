/*
 * Copyright (c) 2020
 * IoTech Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "iot/json.h"

#ifndef _CUTIL_UTEST_JSON_H_
#define _CUTIL_UTEST_JSON_H_

extern void cunit_json_test_init (void);

#endif
