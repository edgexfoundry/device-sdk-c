/*
 * Copyright (c) 2020
 * IoTech Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _CUTIL_UTEST_MISC_H_
#define _CUTIL_UTEST_MISC_H_

extern void cunit_misc_test_init (void);

#endif

