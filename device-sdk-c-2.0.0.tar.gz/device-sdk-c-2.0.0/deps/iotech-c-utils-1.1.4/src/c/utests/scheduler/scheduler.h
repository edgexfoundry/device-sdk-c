/*
 * Copyright (c) 2020
 * IoTech Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef IOT_UTEST_SCHEDULER_H
#define IOT_UTEST_SCHEDULER_H

extern void cunit_scheduler_test_init (void);

#endif //IOT_SCHEDULER_H
