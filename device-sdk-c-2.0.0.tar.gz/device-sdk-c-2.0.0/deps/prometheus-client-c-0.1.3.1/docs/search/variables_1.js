var searchData=
[
  ['prom_5fcollector_5fregistry_5fdefault',['PROM_COLLECTOR_REGISTRY_DEFAULT',['../prom__collector__registry_8h.html#a6092b48e150390c1927da5fe8914981b',1,'prom_collector_registry.h']]],
  ['prom_5fhistogram_5fdefault_5fbuckets',['prom_histogram_default_buckets',['../prom__histogram__buckets_8h.html#aa8d61c1abc355eb54173b27cb1b50a5d',1,'prom_histogram_buckets.h']]]
];
