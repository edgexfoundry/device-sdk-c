#ifndef _CSDK_DEFS_H_
#define _CSDK_DEFS_H_

#define CSDK_VERSION 2.0.0
#define CSDK_VERSION_STR "2.0.0"
#define CSDK_SYSTEM_NAME Linux
#define CSDK_Linux 1

#endif
