/*
 * Copyright (c) 2020
 * IoTech Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "iot/typecode.h"
#include "iot/config.h"

#ifndef _CUTIL_UTEST_DATA_H_
#define _CUTIL_UTEST_DATA_H_

extern void cunit_data_test_init (void);

#endif
