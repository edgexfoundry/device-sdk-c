#ifndef _IOT_DEFS_H_
#define _IOT_DEFS_H_

#define IOT_VERSION "1.1.4"
#define IOT_HAS_XML

#endif
